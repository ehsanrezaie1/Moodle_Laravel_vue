<?php

defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_custom_service';
$plugin->version  = 2020071507;
$plugin->requires = 2016052314;
